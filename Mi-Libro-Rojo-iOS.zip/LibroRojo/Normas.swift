import SwiftUI

private let types: [(key: String, name: String, prefix: String)] = [
    ("ley", "Ley", "LEY QUE"), ("normativa", "Normativa", "NORMATIVA QUE"),
    ("reglamento", "Reglamento", "REGLAMENTO QUE"), ("rescripto", "Rescripto", "RESCRIPTO QUE"),
    ("disposicion", "Disposición", "DISPOSICIÓN QUE"), ("regulacion", "Regulación", "REGULACIÓN QUE"),
    ("ley_declarativa", "Ley declarativa", "LEY DECLARATIVA QUE"),
    ("pronunciamiento", "Pronunciamiento", "PRONUNCIAMIENTO QUE"), ("otro", "Otro", "")
]

struct NormasView: View {
    @Binding var book: Book
    @AppStorage("normasPage") private var rules = false
    @Binding var term: String
    @State private var status = "Todas"
    @State private var type = "Todos"
    @State private var editing: Norma?
    @State private var ruleEditor: MarcoComunRegla?

    private var visible: [Norma] {
        book.normas.filter { row in
            (status == "Todas" || row.status == status) &&
            (type == "Todos" || row.type == type) &&
            (!term.filled || [row.fullTitle, row.displayId, row.issuedBy, row.content].contains { $0.localizedCaseInsensitiveContains(term) })
        }.sorted { $0.date > $1.date }
    }

    var body: some View {
        BookPage {
            Picker("Registro", selection: $rules) {
                Text("Normas (\(book.normas.count))").tag(false)
                Text("Marco Común (\(book.marcoComun.count))").tag(true)
            }
            .pickerStyle(.segmented)

            HStack {
                SectionHeading(title: rules ? "Marco Común" : "Normas y leyes", symbol: rules ? "scroll" : "building.columns")
                Spacer()
                NavigationLink {
                    NewspaperView(entries: $book.newspaper)
                } label: {
                    Image(systemName: "newspaper")
                        .font(.headline)
                        .frame(width: 42, height: 42)
                        .glassEffect(.regular.interactive(), in: .circle)
                }
                .accessibilityLabel("Periódico")
                GlassAdd {
                    if rules { ruleEditor = MarcoComunRegla(number: (book.marcoComun.map(\.number).max() ?? 0) + 1) }
                    else { editing = Norma(randomCode: newCode(book.normas.map(\.randomCode)), type: "ley", date: today(), status: "vigente") }
                }
            }
            if rules {
                if book.marcoComun.isEmpty { EmptyRows(title: "Sin reglas", symbol: "scroll") }
                ForEach(book.marcoComun.filter { !term.filled || $0.text.localizedCaseInsensitiveContains(term) || String($0.number).contains(term) }.sorted { $0.number < $1.number }) { row in
                    Button { ruleEditor = row } label: {
                        PaperCard {
                            Text("Regla #\(row.number)").font(.headline.monospaced()).foregroundStyle(wine)
                            Text(row.text)
                        }
                    }.buttonStyle(.plain)
                }
            } else {
                HStack {
                    count("Total", book.normas.count, .primary)
                    count("Vigentes", book.normas.filter { $0.status == "vigente" }.count, .green)
                    count("Derogadas", book.normas.filter { $0.status == "derogada" }.count, wine)
                }

                HStack {
                    Picker("Tipo", selection: $type) {
                        Text("Todos los tipos").tag("Todos")
                        ForEach(types.indices, id: \.self) { index in Text(types[index].name).tag(types[index].key) }
                    }
                    Spacer()
                    Picker("Estado", selection: $status) {
                        Text("Todas").tag("Todas")
                        Text("Vigentes").tag("vigente")
                        Text("Derogadas").tag("derogada")
                    }
                }
                if visible.isEmpty { EmptyRows(title: "Sin normas", symbol: "building.columns") }
                ForEach(visible) { row in
                    NavigationLink {
                        NormaDetail(id: row.id, book: $book)
                    } label: {
                        NormaCard(row: row, book: book)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .sheet(item: $editing) { row in NormaEditor(row: row, book: $book) }
        .sheet(item: $ruleEditor) { row in
            EntryEditor(row, title: "Regla #\(row.number)", valid: { $0.text.filled }, save: { book.marcoComun.put($0) },
                        delete: book.marcoComun.contains { $0.id == row.id } ? {
                book.marcoComun.removeAll { $0.id == row.id }
                for index in book.normas.indices { book.normas[index].marcoComunCorrespondencias.removeAll { $0 == row.id } }
            } : nil) { value in
                MultilineField(title: "Texto", text: value.text)
            }
        }
    }

    private func count(_ label: String, _ value: Int, _ color: Color) -> some View {
        PaperCard {
            Text(label).font(.caption).foregroundStyle(.secondary)
            Text(value.formatted()).font(.headline.monospaced()).foregroundStyle(color)
        }
    }
}

private struct NormaCard: View {
    var row: Norma
    var book: Book
    @State private var excerpt = ""

    var body: some View {
        PaperCard {
            HStack {
                Text(row.displayId).font(.subheadline.monospaced().bold()).foregroundStyle(wine)
                Spacer()
                Text(row.status.capitalized)
                    .font(.caption.bold())
                    .foregroundStyle(row.status == "vigente" ? Color.green : Color.secondary)
            }
            Text(row.fullTitle).font(.headline).strikethrough(row.status == "derogada")
            let related = book.normas.filter { row.correspondencias.contains($0.id) }.map(\.displayId)
                + book.marcoComun.filter { row.marcoComunCorrespondencias.contains($0.id) }.map { "Regla #\($0.number)" }
            if !related.isEmpty {
                Text("Correspondencias · " + related.joined(separator: " · ")).font(.caption).foregroundStyle(.secondary)
            }
            if row.status == "vigente", excerpt.filled {
                Text(excerpt).font(.system(.subheadline, design: .serif).italic()).foregroundStyle(.secondary).lineLimit(2)
            }
            HStack {
                Text(row.issuedBy).lineLimit(1)
                Spacer()
                Text(row.date).monospacedDigit()
            }.font(.caption).foregroundStyle(.secondary)
        }
        .task(id: row.content) {
            let words = row.content.split(whereSeparator: \.isWhitespace)
            let start = Int.random(in: 0...max(0, words.count - 22))
            let fragment = words.dropFirst(start).prefix(22).joined(separator: " ")
            excerpt = (start > 0 ? "… " : "") + String(fragment.prefix(130))
                + (fragment.count > 130 || start + 22 < words.count ? " …" : "")
        }
    }
}

private struct NormaDetail: View {
    var id: String
    @Binding var book: Book
    @State private var editing: Norma?
    @State private var repeal: Norma?

    var body: some View {
        BookPage {
            if let row = book.normas.first(where: { $0.id == id }) {
                PaperCard {
                    Text(row.fullTitle).font(.title2.bold()).strikethrough(row.status == "derogada")
                    Text([row.issuedBy, row.date].filter(\.filled).joined(separator: " · ")).foregroundStyle(.secondary)
                    Text(row.content).textSelection(.enabled)
                    if row.status == "derogada" {
                        Divider()
                        Text("Derogada").font(.headline)
                        Text([row.derogatedAt, row.derogatedByName, row.derogatedBy, row.derogationReason].compactMap { $0 }.filter(\.filled).joined(separator: "\n"))
                    }
                }
                let linked = book.normas.filter { row.correspondencias.contains($0.id) }
                let rules = book.marcoComun.filter { row.marcoComunCorrespondencias.contains($0.id) }
                if !linked.isEmpty || !rules.isEmpty {
                    PaperCard {
                        Text("Correspondencias").font(.headline)
                        ForEach(linked) { linkedRow in
                            NavigationLink(linkedRow.displayId) { NormaDetail(id: linkedRow.id, book: $book) }
                        }
                        ForEach(rules) { rule in Text("Regla #\(rule.number) · \(rule.text)") }
                    }
                }
                Button("Editar norma", systemImage: "pencil") { editing = row }.buttonStyle(.glass)
                if row.status == "vigente" {
                    Button("Derogar", systemImage: "xmark.seal") {
                        var draft = row
                        draft.derogatedAt = today()
                        repeal = draft
                    }.buttonStyle(.glass)
                }
            }
        }
        .navigationTitle("Norma")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $editing) { row in NormaEditor(row: row, book: $book) }
        .sheet(item: $repeal) { row in
            EntryEditor(row, title: "Derogar norma", valid: { $0.derogationReason?.filled == true }, save: { item in
                var result = item
                result.status = "derogada"
                if let link = book.normas.first(where: { $0.id == item.derogatedByNormaId }) {
                    result.derogatedByName = link.displayId
                }
                book.normas.put(result)
            }) { draft in
                TextField("Instrumento derogatorio", text: optionalText(draft.derogatedByName))
                Picker("Norma derogatoria", selection: optionalText(draft.derogatedByNormaId)) {
                    Text("Sin vínculo").tag("")
                    ForEach(book.normas.filter { $0.id != row.id && $0.status == "vigente" }) { link in
                        Text(link.displayId).tag(link.id)
                    }
                }
                TextField("Quién ordenó la derogación", text: optionalText(draft.derogatedBy))
                MultilineField(title: "Motivo", text: optionalText(draft.derogationReason))
                DayField(title: "Fecha", value: optionalText(draft.derogatedAt))
            }
        }
    }
}

private struct NormaEditor: View {
    var row: Norma
    @Binding var book: Book

    var body: some View {
        EntryEditor(row, title: row.displayId.isEmpty ? "Nueva norma" : "Editar norma", valid: {
            $0.titleSuffix.filled && ($0.type != "otro" || $0.customTypeLabel?.filled == true)
        }, save: { draft in
            var item = draft
            if let kind = types.first(where: { $0.key == item.type }) {
                let name = kind.key == "otro" ? (item.customTypeLabel ?? kind.name) : kind.name
                item.displayId = "\(name) N° \(item.randomCode)"
                item.fullTitle = [kind.key == "otro" ? name.uppercased() + " QUE" : kind.prefix, item.titleSuffix].joined(separator: " ")
            }
            book.normas.put(item)
        }) { draft in
            Picker("Tipo", selection: draft.type) {
                ForEach(types.indices, id: \.self) { index in Text(types[index].name).tag(types[index].key) }
            }
            if draft.wrappedValue.type == "otro" { TextField("Nombre del tipo", text: optionalText(draft.customTypeLabel)) }
            if let kind = types.first(where: { $0.key == draft.wrappedValue.type }), !kind.prefix.isEmpty {
                Text(kind.prefix + "…")
                    .font(.caption).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
            }
            TextField("Título", text: draft.titleSuffix)
            TextField("Quién la dio", text: draft.issuedBy)
            DayField(title: "Fecha", value: draft.date)
            MultilineField(title: "Contenido", text: draft.content)
            Section {
                DisclosureGroup("Correspondencias") {
                    ForEach(book.normas.filter {
                        $0.id != row.id && ($0.status == "vigente" || row.correspondencias.contains($0.id))
                    }) { item in
                        CorrespondenceCheck(title: item.displayId, selected: membership(item.id, in: draft.correspondencias))
                            .disabled(item.status != "vigente")
                    }
                    ForEach(book.marcoComun) { rule in
                        CorrespondenceCheck(title: "Regla #\(rule.number)", selected: membership(rule.id, in: draft.marcoComunCorrespondencias))
                    }
                }
            }
        }
    }
}

func optionalText(_ source: Binding<String?>) -> Binding<String> {
    Binding(get: { source.wrappedValue ?? "" }, set: { source.wrappedValue = $0.filled ? $0 : nil })
}

private func membership(_ key: String, in list: Binding<[String]>) -> Binding<Bool> {
    Binding(get: { list.wrappedValue.contains(key) }, set: { selected in
        list.wrappedValue.removeAll { $0 == key }
        if selected { list.wrappedValue.append(key) }
    })
}

struct NewspaperView: View {
    @Binding var entries: [NewspaperEntry]
    @State private var editing: NewspaperEntry?

    var body: some View {
        BookPage {
            ForEach(entries) { entry in
                if entry.id != entries.first?.id {
                    GeometryReader { geometry in
                        Text(String(repeating: "-", count: max(1, Int(geometry.size.width / 8.4))))
                            .font(.system(size: 14, design: .monospaced))
                            .foregroundStyle(.secondary).lineLimit(1).fixedSize()
                    }.frame(height: 18).clipped().accessibilityHidden(true)
                }
                Button { editing = entry } label: {
                    Text(entry.text)
                        .font(.system(.body, design: .monospaced))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }.buttonStyle(.plain)
            }
            if entries.isEmpty { EmptyRows(title: "Sin entradas", symbol: "newspaper").fontDesign(.monospaced) }
        }
        .navigationTitle("Periódico")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Nueva entrada", systemImage: "plus") { editing = NewspaperEntry() }
            }
        }
        .sheet(item: $editing) { row in
            EntryEditor(row, title: "Periódico", valid: { $0.text.filled }, save: { entries.put($0) },
                        delete: entries.contains { $0.id == row.id } ? { entries.removeAll { $0.id == row.id } } : nil) { value in
                MultilineField(title: "Texto", text: value.text, mono: true)
            }.fontDesign(.monospaced)
        }
    }
}


private struct CorrespondenceCheck: View {
    var title: String
    @Binding var selected: Bool

    var body: some View {
        Button { selected.toggle() } label: {
            HStack {
                Text(title).foregroundStyle(.primary)
                Spacer()
                if selected { Image(systemName: "checkmark").foregroundStyle(wine) }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityValue(selected ? "Seleccionada" : "Sin seleccionar")
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}
