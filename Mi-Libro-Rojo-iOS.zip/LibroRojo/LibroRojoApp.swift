import SwiftUI
import UniformTypeIdentifiers

let ruby = Color(red: 0.54, green: 0.07, blue: 0.21)
let wine = Color(red: 0.76, green: 0.04, blue: 0.26)

func today() -> String { dayString(.now) }

func dayString(_ date: Date) -> String { BookDate.storage(date) }

func nowStamp() -> String { BookDate.storage(.now, time: true) }

func soles(_ value: Double) -> String {
    "S/ " + value.formatted(.number.locale(Locale(identifier: "en_US")).precision(.fractionLength(2)))
}

func newCode(_ used: [Int]) -> Int {
    let occupied = Set(used)
    guard occupied.count < 90_000 else { return 0 }
    var number = Int.random(in: 10000...99999)
    while occupied.contains(number) { number = Int.random(in: 10000...99999) }
    return number
}

extension Array where Element: Identifiable {
    mutating func put(_ item: Element) {
        if let index = firstIndex(where: { $0.id == item.id }) { self[index] = item }
        else { insert(item, at: 0) }
    }
}

@main
struct LibroRojoApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
    }
}

struct BackupDocument: FileDocument {
    static let readableContentTypes: [UTType] = [.json]
    var data: Data

    init(data: Data) { self.data = data }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        self.data = data
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct RootView: View {
    @AppStorage("bookBackup") private var stored = Data()
    @AppStorage("activeTab") private var tab = "normas"
    @State private var book = Book(currencyEntries: Book.historicalRates)
    @State private var queries: [String: String] = [:]
    @State private var searchOpen = false
    @State private var loaded = false
    @State private var importing = false
    @State private var exporting = false
    @State private var pendingImport: Book?
    @State private var taskImport = false
    @State private var confirmation = false
    @State private var message = ""
    @State private var showMessage = false
    @State private var document = BackupDocument(data: Data())

    var body: some View {
        TabView(selection: $tab) {
            Tab("Normas", systemImage: "building.columns", value: "normas") {
                section("Normas") { NormasView(book: $book, term: query("normas")) }
            }
            Tab("Vetos", systemImage: "nosign", value: "vetos") {
                section("Vetos") { VetosView(book: $book, term: query("vetos")) }
            }
            Tab("Economía", systemImage: "chart.line.uptrend.xyaxis", value: "economia") {
                section("Economía") { EconomiaView(book: $book, term: query("economia")) }
            }
            Tab("Avances", systemImage: "trophy", value: "avances") {
                section("Avances") { AvancesView(book: $book, term: query("avances")) }
            }
            Tab("Pendientes", systemImage: "checklist", value: "pendientes") {
                section("Pendientes") { PendientesView(book: $book, term: query("pendientes")) }
            }
        }
        .tint(wine)
        .sheet(isPresented: $searchOpen) {
            SearchPanel(text: query(tab))
                .presentationDetents([.height(180)])
                .presentationDragIndicator(.visible)
        }
        .task {
            guard !loaded else { return }
            if let saved = try? JSONDecoder().decode(Book.self, from: stored) { book = saved }
            loaded = true
        }
        .onChange(of: encodedBook) { _, data in
            if loaded, let data { stored = data }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            do {
                let url = try result.get()
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let data = try Data(contentsOf: url)
                if taskImport {
                    try importTasks(data)
                } else {
                    pendingImport = try JSONDecoder().decode(Book.self, from: data)
                    confirmation = true
                }
            } catch {
                report(taskImport ? "Elige un archivo de pendientes válido." : "No se pudo leer la copia. Selecciona el JSON exportado por Mi Libro Rojo.")
            }
        }
        .confirmationDialog("¿Reemplazar los datos de este iPhone con la copia?", isPresented: $confirmation, titleVisibility: .visible) {
            Button("Importar y reemplazar", role: .destructive) {
                if let pendingImport { book = pendingImport }
                pendingImport = nil
            }
            Button("Cancelar", role: .cancel) { pendingImport = nil }
        }
        .fileExporter(isPresented: $exporting, document: document, contentType: .json, defaultFilename: "Mi-Libro-Rojo") { result in
            if case .failure = result { report("No se pudo exportar la copia.") }
        }
        .alert("Mi Libro Rojo", isPresented: $showMessage) {
            Button("Aceptar", role: .cancel) {}
        } message: { Text(message) }
    }

    private func query(_ key: String) -> Binding<String> {
        Binding(get: { queries[key, default: ""] }, set: { queries[key] = $0 })
    }

    private var encodedBook: Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .sortedKeys
        return try? encoder.encode(book)
    }

    private func section<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        NavigationStack {
            content()
                .navigationTitle(title)
                .toolbar {
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        Button("Buscar", systemImage: queries[tab, default: ""].filled ? "magnifyingglass.circle.fill" : "magnifyingglass") {
                            searchOpen = true
                        }
                        Menu {
                            Button("Añadir pendientes desde JSON", systemImage: "checklist") {
                                taskImport = true
                                importing = true
                            }
                            Button("Importar copia JSON", systemImage: "square.and.arrow.down") {
                                taskImport = false
                                importing = true
                            }
                            Button("Exportar copia JSON", systemImage: "square.and.arrow.up", action: export)
                        } label: {
                            Label("Copias de seguridad", systemImage: "ellipsis.circle")
                        }
                    }
                }
        }
    }

    private func importTasks(_ data: Data) throws {
        let batch = try JSONDecoder().decode(TaskBatch.self, from: data)
        guard batch.format == "mi-libro-rojo-pendientes-v1",
              !batch.pendientes.isEmpty,
              batch.pendientes.allSatisfy({ $0.id.filled && $0.content.filled }) else {
            throw CocoaError(.fileReadCorruptFile)
        }

        var ids = Set(book.pendientes.map(\.id))
        var contents = Set(book.pendientes.map { $0.content.subtypeKey })
        let newTasks = batch.pendientes.filter { task in
            guard !ids.contains(task.id), !contents.contains(task.content.subtypeKey) else { return false }
            ids.insert(task.id)
            contents.insert(task.content.subtypeKey)
            return true
        }
        let nextNumber = (book.pendientes.map(\.orderNumber).max() ?? 0) + 1
        let stamp = nowStamp()
        let appended = newTasks.enumerated().map { index, task in
            Pendiente(id: task.id, orderNumber: nextNumber + index, content: task.content,
                      importance: "media", status: "por_hacer", createdAt: stamp)
        }
        book.pendientes.append(contentsOf: appended)
        tab = "pendientes"
        report(appended.isEmpty ? "Estos pendientes ya están en tu lista." : "Se añadieron \(appended.count) pendientes.")
    }

    private func export() {
        do {
            var backup = book
            backup.exportedAt = ISO8601DateFormatter().string(from: .now)
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            document = BackupDocument(data: try encoder.encode(backup))
            exporting = true
        } catch { report("No se pudo preparar la copia.") }
    }

    private func report(_ text: String) {
        message = text
        showMessage = true
    }
}


private struct TaskBatch: Decodable {
    struct Entry: Decodable {
        var id: String
        var content: String
    }

    var format: String
    var pendientes: [Entry]
}
