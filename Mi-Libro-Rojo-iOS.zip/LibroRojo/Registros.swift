import PhotosUI
import SwiftUI
import UIKit

struct VetosView: View {
    @Binding var book: Book
    @State private var editing: Veto?
    @State private var photo: VetoPhotoPreview?
    @Binding var term: String

    private var visible: [Veto] {
        book.vetos.filter {
            !term.filled || $0.name.localizedCaseInsensitiveContains(term) || $0.reasons.localizedCaseInsensitiveContains(term)
        }.sorted { BookDate.sortKey($0.date) > BookDate.sortKey($1.date) }
    }

    var body: some View {
        BookPage {
            HStack {
                SectionHeading(title: "Registro de vetos", symbol: "nosign")
                Spacer()
                GlassAdd { editing = Veto(randomCode: newCode(book.vetos.map(\.randomCode)), targetType: "persona", date: today(), severity: "total", status: "activo") }
            }

            if visible.isEmpty { EmptyRows(title: "Sin vetos", symbol: "nosign") }
            ForEach(visible) { row in
                PaperCard {
                    HStack(alignment: .top) {
                        if row.targetType == "persona", let image = vetoImage(row.photoUrl) {
                            Button {
                                photo = VetoPhotoPreview(image: image, title: row.name)
                            } label: {
                                VetoThumbnail(image: image)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Ver foto de \(row.name)")
                        }
                        Button { editing = row } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                HStack(alignment: .firstTextBaseline) {
                                    Text("Veto N° \(String(row.randomCode))")
                                        .font(.caption.monospaced()).foregroundStyle(wine)
                                    Spacer()
                                    Text(row.status.capitalized).font(.caption.bold())
                                        .foregroundStyle(row.status == "activo" ? wine : Color.secondary)
                                }
                                Text(row.name).font(.headline).strikethrough(row.status == "levantado")
                            }
                            .contentShape(Rectangle())
                        }.buttonStyle(.plain)
                    }
                    Button { editing = row } label: {
                        VStack(alignment: .leading, spacing: 9) {
                            Text(row.reasons).foregroundStyle(.secondary)
                            Text("\(row.severity.capitalized) · \(BookDate.display(row.date))")
                                .font(.caption.monospaced()).foregroundStyle(.secondary)
                            if let reason = row.liftReason, row.status == "levantado" {
                                Text("Levantado · " + reason).font(.caption)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                    }.buttonStyle(.plain)
                }
            }
        }
        .fullScreenCover(item: $photo) { preview in
            VetoPhotoViewer(preview: preview)
        }
        .sheet(item: $editing) { row in
            let existing = book.vetos.contains { $0.id == row.id }
            EntryEditor(row, title: existing ? "Editar veto" : "Nuevo veto", valid: { $0.name.filled && $0.reasons.filled }, save: { draft in
                var item = draft
                if item.severity == "total" { item.status = "activo" }
                if item.status == "levantado" { item.liftedAt = item.liftedAt ?? today() }
                else { item.liftedAt = nil; item.liftReason = nil }
                book.vetos.put(item)
            }, delete: existing ? { book.vetos.removeAll { $0.id == row.id } } : nil) { item in
                Picker("Tipo", selection: item.targetType) {
                    Text("Persona").tag("persona")
                    Text("Situación").tag("situacion")
                }
                TextField("Nombre", text: item.name)
                if item.wrappedValue.targetType == "persona" { VetoPhotoPicker(url: item.photoUrl) }
                Picker("Alcance", selection: item.severity) {
                    Text("Total inapelable").tag("total")
                    Text("Parcial").tag("parcial")
                    Text("Indefinido").tag("indefinido")
                }.disabled(existing && row.severity == "total")
                DayField(title: "Fecha", value: item.date)
                MultilineField(title: "Razones y fundamentos", text: item.reasons)
                if existing && item.wrappedValue.severity != "total" {
                    Picker("Estado", selection: item.status) {
                        Text("Activo").tag("activo")
                        Text("Levantado").tag("levantado")
                    }
                }
                if item.wrappedValue.status == "levantado" && item.wrappedValue.severity != "total" {
                    MultilineField(title: "Motivo del levantamiento", text: optionalText(item.liftReason))
                }
            }
        }
    }
}

private func vetoImage(_ url: String?) -> UIImage? {
    guard let url, url.hasPrefix("data:image/"),
          let comma = url.firstIndex(of: ","),
          let data = Data(base64Encoded: String(url[url.index(after: comma)...])) else { return nil }
    return UIImage(data: data)
}

private struct VetoThumbnail: View {
    var image: UIImage

    var body: some View {
        Image(uiImage: image).resizable().scaledToFill()
            .frame(width: 42, height: 42)
            .clipShape(.circle)
    }
}

private struct VetoPhotoPreview: Identifiable {
    var id = UUID()
    var image: UIImage
    var title: String
}

private struct VetoPhotoViewer: View {
    var preview: VetoPhotoPreview
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Image(uiImage: preview.image)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .accessibilityLabel(preview.title)
            Button("Cerrar foto", systemImage: "xmark") { dismiss() }
                .labelStyle(.iconOnly)
                .buttonStyle(.glass)
                .tint(.white)
                .padding()
        }
        .preferredColorScheme(.dark)
    }
}

private struct VetoPhotoPicker: View {
    @Binding var url: String?
    @State private var selection: PhotosPickerItem?
    @State private var failed = false

    var body: some View {
        HStack {
            if let image = vetoImage(url) { VetoThumbnail(image: image) }
            PhotosPicker(selection: $selection, matching: .images) { Label("Elegir foto", systemImage: "photo") }
            if url != nil { Button("Quitar", role: .destructive) { url = nil; selection = nil }.buttonStyle(.borderless) }
        }
        .task(id: selection) {
            guard let selection else { return }
            do {
                guard let data = try await selection.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { failed = true; return }
                let ratio = min(1, 600 / max(image.size.width, image.size.height))
                let size = CGSize(width: max(1, image.size.width * ratio), height: max(1, image.size.height * ratio))
                let format = UIGraphicsImageRendererFormat()
                format.scale = 1
                let scaled = UIGraphicsImageRenderer(size: size, format: format).image { _ in
                    image.draw(in: CGRect(origin: .zero, size: size))
                }
                if let jpeg = scaled.jpegData(compressionQuality: 0.8), !Task.isCancelled {
                    url = "data:image/jpeg;base64," + jpeg.base64EncodedString()
                }
            } catch { if !Task.isCancelled { failed = true } }
        }
        .alert("No se pudo abrir la foto", isPresented: $failed) { Button("Aceptar", role: .cancel) {} }
    }
}

struct AvancesView: View {
    @Binding var book: Book
    @State private var editing: Logro?
    @Binding var term: String

    private var visible: [Logro] {
        book.logros.filter {
            !term.filled || [$0.title, $0.description, $0.category].contains { $0.localizedCaseInsensitiveContains(term) }
        }.sorted { BookDate.sortKey($0.date) > BookDate.sortKey($1.date) }
    }

    var body: some View {
        BookPage {
            HStack {
                SectionHeading(title: "Registro de avances", symbol: "trophy")
                Spacer()
                GlassAdd { editing = Logro(date: today()) }
            }

            if visible.isEmpty { EmptyRows(title: "Sin avances", symbol: "trophy") }
            ForEach(visible) { row in
                Button { editing = row } label: {
                    PaperCard {
                        Text(row.title).font(.headline)
                        if row.description.filled { Text(row.description) }
                        HStack {
                            Text([row.category, BookDate.display(row.date)].filter(\.filled).joined(separator: " · "))
                                .foregroundStyle(.secondary)
                            Spacer()
                            if let amount = row.amountSoles { Text(soles(amount)).foregroundStyle(.green) }
                        }.font(.caption.monospaced())
                    }
                }.buttonStyle(.plain)
            }
        }
        .sheet(item: $editing) { row in
            EntryEditor(row, title: "Avance", valid: { $0.title.filled },
                        save: { book.logros.put($0) }, delete: book.logros.contains { $0.id == row.id } ? {
                book.logros.removeAll { $0.id == row.id }
            } : nil) { item in
                TextField("Título", text: item.title)
                TextField("Categoría", text: item.category)
                DayField(title: "Fecha", value: item.date)
                DecimalField(title: "Monto opcional en soles", value: Binding(get: {
                    item.wrappedValue.amountSoles ?? 0
                }, set: { item.wrappedValue.amountSoles = $0 == 0 ? nil : $0 }))
                MultilineField(title: "Descripción", text: item.description)
            }
        }
    }
}

private let taskStates = [
    ("por_hacer", "Por hacer"), ("en_proceso", "En proceso"), ("priorizada", "Priorizada"),
    ("aplazada", "Aplazada"), ("completada", "Completada")
]

private func isDone(_ status: String) -> Bool { ["cumplida", "completada", "priorizada"].contains(status) }

struct PendientesView: View {
    @Binding var book: Book
    @State private var editing: Pendiente?
    @Binding var term: String
    @State private var filter = "todas"

    private var visible: [Pendiente] {
        orderedTasks(book.pendientes).filter {
            (filter == "todas" || filter == $0.status || (filter == "completada" && $0.status == "cumplida"))
            && (!term.filled || $0.content.localizedCaseInsensitiveContains(term)
                || ($0.notes ?? "").localizedCaseInsensitiveContains(term) || String($0.orderNumber).contains(term))
        }
    }

    private func orderedTasks(_ rows: [Pendiente]) -> [Pendiente] {
        let processed = rows.filter { isDone($0.status) || $0.status == "en_proceso" }.sorted {
            if isDone($0.status) != isDone($1.status) { return isDone($0.status) }
            let a = $0.processingOrder ?? $0.orderNumber
            let b = $1.processingOrder ?? $1.orderNumber
            return a == b ? $0.id < $1.id : a < b
        }
        let pending = rows.filter { !isDone($0.status) && $0.status != "en_proceso" }.sorted {
            let a = $0.dueDate.isEmpty ? $0.createdAt : $0.dueDate
            let b = $1.dueDate.isEmpty ? $1.createdAt : $1.dueDate
            let first = BookDate.sortKey(a)
            let second = BookDate.sortKey(b)
            if first != second { return first < second }
            let firstCreated = BookDate.sortKey($0.createdAt)
            let secondCreated = BookDate.sortKey($1.createdAt)
            return firstCreated == secondCreated ? $0.id < $1.id : firstCreated < secondCreated
        }
        return (processed + pending).enumerated().map { index, row in
            var result = row
            result.orderNumber = index + 1
            result.processingOrder = index < processed.count ? index + 1 : nil
            return result
        }
    }

    var body: some View {
        BookPage {
            HStack {
                SectionHeading(title: "Tareas", symbol: "checklist")
                Spacer()
                GlassAdd {
                    editing = Pendiente(orderNumber: (book.pendientes.map(\.orderNumber).max() ?? 0) + 1,
                                       dueDate: today(), importance: "media", status: "por_hacer", createdAt: nowStamp())
                }
            }
            HStack {

                Picker("Estado", selection: $filter) {
                    Text("Todas").tag("todas")
                    ForEach(taskStates.indices, id: \.self) { index in
                        Text(taskStates[index].1).tag(taskStates[index].0)
                    }
                }
            }
            if visible.isEmpty { EmptyRows(title: "Sin pendientes", symbol: "checklist") }
            ForEach(visible) { row in
                PaperCard {
                    HStack(alignment: .top) {
                        Button {
                            var updated = row
                            updated.status = isDone(row.status) ? "por_hacer" : "completada"
                            save(updated)
                        } label: {
                            Image(systemName: isDone(row.status) ? "checkmark.circle.fill" : "circle")
                                .font(.title2).foregroundStyle(isDone(row.status) ? Color.green : wine)
                                .frame(width: 44, height: 44)
                        }.buttonStyle(.plain)
                            .accessibilityLabel(isDone(row.status) ? "Reabrir tarea" : "Completar tarea")
                        Button {
                            var draft = row
                            if draft.status == "cumplida" { draft.status = "completada" }
                            editing = draft
                        } label: {
                            VStack(alignment: .leading, spacing: 5) {
                                Text("#\(row.orderNumber) · \(row.content)")
                                    .font(.headline).strikethrough(isDone(row.status))
                                Text([taskStates.first { $0.0 == row.status || ($0.0 == "completada" && isDone(row.status)) }?.1 ?? row.status,
                                      row.importance.capitalized, BookDate.display(row.dueDate)].filter(\.filled).joined(separator: " · "))
                                    .font(.caption).foregroundStyle(.secondary)
                                if row.status == "aplazada", let date = row.postponedUntil { Text("Aplazada hasta " + BookDate.display(date)).font(.caption) }
                            }.frame(maxWidth: .infinity, alignment: .leading)
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
        .sheet(item: $editing) { row in
            EntryEditor(row, title: "Pendiente #\(row.orderNumber)", valid: { $0.content.filled },
                        save: save, delete: book.pendientes.contains { $0.id == row.id } ? {
                book.pendientes = orderedTasks(book.pendientes.filter { $0.id != row.id })
            } : nil) { item in
                MultilineField(title: "Acción", text: item.content)
                DayField(title: "Fecha límite", value: item.dueDate)
                Picker("Importancia", selection: item.importance) {
                    Text("Baja").tag("baja")
                    Text("Media").tag("media")
                    Text("Alta").tag("alta")
                    Text("Crítica").tag("critica")
                }
                Picker("Estado", selection: item.status) {
                    ForEach(taskStates.indices, id: \.self) { index in
                        Text(taskStates[index].1).tag(taskStates[index].0)
                    }
                }
                if item.wrappedValue.status == "aplazada" {
                    DayField(title: "Aplazar hasta", value: Binding(get: {
                        item.wrappedValue.postponedUntil ?? today()
                    }, set: { item.wrappedValue.postponedUntil = $0 }))
                    TextField("Motivo", text: optionalText(item.postponeReason))
                }
                MultilineField(title: "Notas", text: optionalText(item.notes))
            }
        }
    }

    private func save(_ draft: Pendiente) {
        var item = draft
        item.completedAt = isDone(item.status) ? (item.completedAt ?? nowStamp()) : nil
        if item.status == "aplazada" { item.postponedUntil = item.postponedUntil ?? today() }
        else { item.postponedUntil = nil; item.postponeReason = nil }
        if item.status == "en_proceso" || isDone(item.status) {
            let old = book.pendientes.first { $0.id == item.id }
            let next = (book.pendientes.compactMap(\.processingOrder).max() ?? 0) + 1
            item.processingOrder = old.map { isDone($0.status) == isDone(item.status) ? ($0.processingOrder ?? next) : next } ?? next
        } else { item.processingOrder = nil }
        var rows = orderedTasks(book.pendientes)
        rows.put(item)
        book.pendientes = orderedTasks(rows)
    }
}
