import SwiftUI

struct BookPage<Content: View>: View {
    @Environment(\.colorScheme) private var scheme
    @ViewBuilder var content: Content

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) { content }
                .padding(16)
                .frame(maxWidth: 720)
                .frame(maxWidth: .infinity)
        }
        .background {
            ZStack(alignment: .top) {
                (scheme == .dark ? Color(red: 0.09, green: 0.025, blue: 0.045) : Color(red: 0.98, green: 0.96, blue: 0.95))
                LinearGradient(colors: [ruby.opacity(scheme == .dark ? 0.55 : 0.13), .clear], startPoint: .top, endPoint: .bottom)
                    .frame(height: 310)
            }
            .ignoresSafeArea()
        }
    }
}

struct PaperCard<Content: View>: View {
    @Environment(\.colorScheme) private var scheme
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 9) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(scheme == .dark ? Color(red: 0.15, green: 0.07, blue: 0.10) : .white, in: .rect(cornerRadius: 20))
            .overlay { RoundedRectangle(cornerRadius: 20).strokeBorder(ruby.opacity(0.16)) }
    }
}

struct GlassAdd: View {
    var label = "Añadir"
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: "plus")
                .font(.headline)
                .frame(width: 42, height: 42)
                .foregroundStyle(wine)
                .glassEffect(.regular.tint(wine.opacity(0.18)).interactive(), in: .circle)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

struct SectionHeading: View {
    var title: String
    var symbol: String

    var body: some View {
        Label(title, systemImage: symbol)
            .font(.system(.title2, design: .serif, weight: .bold))
            .foregroundStyle(.primary)
            .accessibilityAddTraits(.isHeader)
    }
}

struct EmptyRows: View {
    var title: String
    var symbol: String
    var body: some View {
        ContentUnavailableView(title, systemImage: symbol)
            .frame(maxWidth: .infinity)
    }
}

struct EntryEditor<Value, Fields: View>: View {
    @Environment(\.dismiss) private var dismiss
    @State private var value: Value
    @State private var confirming = false
    var title: String
    var valid: (Value) -> Bool
    var save: (Value) -> Void
    var delete: (() -> Void)?
    var fields: (Binding<Value>) -> Fields
    var toolbarTint: (Value) -> Color

    init(_ value: Value, title: String, valid: @escaping (Value) -> Bool, save: @escaping (Value) -> Void,
         delete: (() -> Void)? = nil, toolbarTint: @escaping (Value) -> Color = { _ in wine }, @ViewBuilder fields: @escaping (Binding<Value>) -> Fields) {
        _value = State(initialValue: value)
        self.title = title
        self.valid = valid
        self.save = save
        self.delete = delete
        self.fields = fields
        self.toolbarTint = toolbarTint
    }

    var body: some View {
        NavigationStack {
            Form {
                fields($value)
                if delete != nil {
                    Button("Eliminar entrada", role: .destructive) { confirming = true }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() }.tint(toolbarTint(value)) }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") { save(value); dismiss() }
                        .tint(toolbarTint(value))
                        .disabled(!valid(value))
                }
            }
            .confirmationDialog("¿Eliminar esta entrada?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Eliminar", role: .destructive) { delete?(); dismiss() }
            }
        }
    }
}

struct MultilineField: View {
    var title: String
    @Binding var text: String
    var mono = false

    var body: some View {
        Section(title) {
            TextEditor(text: $text)
                .font(mono ? .system(.body, design: .monospaced) : .body)
                .frame(minHeight: 125)
                .accessibilityLabel(title)
        }
    }
}

struct DayField: View {
    var title: String
    @Binding var value: String

    var body: some View {
        DatePicker(title, selection: Binding(
            get: { DateFormatter.isoDay.date(from: value) ?? .now },
            set: { value = dayString($0) }
        ), displayedComponents: .date)
    }
}

private extension DateFormatter {
    static var isoDay: DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }
}

extension String {
    var filled: Bool { !trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
}


struct SearchPanel: View {
    @Binding var text: String
    @Environment(\.dismiss) private var dismiss
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            HStack(spacing: 12) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Buscar", text: $text)
                    .focused($focused)
                    .submitLabel(.search)
                    .onSubmit { dismiss() }
                if text.filled {
                    Button("Borrar búsqueda", systemImage: "xmark.circle.fill") { text = "" }
                        .labelStyle(.iconOnly).foregroundStyle(.secondary)
                }
            }
            .padding(14)
            .glassEffect(.regular, in: .capsule)
            .padding()
            .navigationTitle("Buscar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } }
            }
        }
        .tint(wine)
        .task {
            try? await Task.sleep(for: .milliseconds(250))
            guard !Task.isCancelled else { return }
            focused = true
        }
    }
}
