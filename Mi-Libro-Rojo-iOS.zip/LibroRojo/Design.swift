import SwiftUI

struct BookPage<Content: View>: View {
    @Environment(\.colorScheme) private var scheme
    @ViewBuilder var content: Content

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) { content }
                .padding(16)
                .frame(maxWidth: 720)
                .frame(maxWidth: .infinity)
        }
        .background {
            ZStack(alignment: .top) {
                (scheme == .dark ? Color(red: 0.09, green: 0.025, blue: 0.045) : Color(red: 0.98, green: 0.96, blue: 0.95))
                LinearGradient(colors: [ruby.opacity(scheme == .dark ? 0.55 : 0.13), .clear], startPoint: .top, endPoint: .bottom)
                    .frame(height: 310)
            }
            .ignoresSafeArea()
        }
    }
}

struct PaperCard<Content: View>: View {
    @Environment(\.colorScheme) private var scheme
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 9) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(scheme == .dark ? Color(red: 0.15, green: 0.07, blue: 0.10) : .white, in: .rect(cornerRadius: 20))
            .overlay { RoundedRectangle(cornerRadius: 20).strokeBorder(ruby.opacity(0.16)) }
    }
}

struct GlassAdd: View {
    var label = "Añadir"
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: "plus")
                .font(.headline)
                .frame(width: 42, height: 42)
                .foregroundStyle(wine)
                .glassEffect(.regular.tint(wine.opacity(0.18)).interactive(), in: .circle)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

struct SectionHeading: View {
    var title: String
    var symbol: String

    var body: some View {
        Label(title, systemImage: symbol)
            .font(.system(.title2, design: .serif, weight: .bold))
            .foregroundStyle(.primary)
            .accessibilityAddTraits(.isHeader)
    }
}

struct EmptyRows: View {
    var title: String
    var symbol: String
    var body: some View {
        ContentUnavailableView(title, systemImage: symbol)
            .frame(maxWidth: .infinity)
    }
}

struct EntryEditor<Value, Fields: View>: View {
    @Environment(\.dismiss) private var dismiss
    @State private var value: Value
    @State private var confirming = false
    var title: String
    var valid: (Value) -> Bool
    var save: (Value) -> Void
    var delete: (() -> Void)?
    var fields: (Binding<Value>) -> Fields
    var toolbarTint: (Value) -> Color

    init(_ value: Value, title: String, valid: @escaping (Value) -> Bool, save: @escaping (Value) -> Void,
         delete: (() -> Void)? = nil, toolbarTint: @escaping (Value) -> Color = { _ in wine }, @ViewBuilder fields: @escaping (Binding<Value>) -> Fields) {
        _value = State(initialValue: value)
        self.title = title
        self.valid = valid
        self.save = save
        self.delete = delete
        self.fields = fields
        self.toolbarTint = toolbarTint
    }

    var body: some View {
        NavigationStack {
            Form {
                fields($value)
                if delete != nil {
                    Button("Eliminar entrada", role: .destructive) { confirming = true }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() }.tint(toolbarTint(value)) }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") { save(value); dismiss() }
                        .tint(toolbarTint(value))
                        .disabled(!valid(value))
                }
            }
            .confirmationDialog("¿Eliminar esta entrada?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Eliminar", role: .destructive) { delete?(); dismiss() }
            }
        }
    }
}

struct MultilineField: View {
    var title: String
    @Binding var text: String
    var mono = false

    var body: some View {
        Section(title) {
            TextEditor(text: $text)
                .font(mono ? .system(.body, design: .monospaced) : .body)
                .frame(minHeight: 125)
                .accessibilityLabel(title)
        }
    }
}

struct DayField: View {
    var title: String
    @Binding var value: String
    var includesTime = false
    @State private var choosing = false

    var body: some View {
        LabeledContent(title) {
            Button {
                choosing = true
            } label: {
                Text(value.isEmpty ? "Elegir fecha" : BookDate.display(value, time: includesTime))
                    .monospacedDigit()
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .foregroundStyle(.primary)
                    .background(.quaternary, in: .capsule)
            }
            .buttonStyle(.plain)
            .popover(isPresented: $choosing) {
                VStack(spacing: 10) {
                    DatePicker(title, selection: Binding(
                        get: { BookDate.parse(value) ?? .now },
                        set: { value = BookDate.storage($0, time: includesTime) }
                    ), displayedComponents: includesTime ? [.date, .hourAndMinute] : .date)
                    .datePickerStyle(.graphical)
                    Button("Listo") { choosing = false }
                        .buttonStyle(.glass)
                }
                .padding()
                .frame(minWidth: 290, idealWidth: 320)
                .presentationCompactAdaptation(.popover)
            }
        }
    }
}

enum BookDate {
    private static func formatter(_ format: String) -> DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = format
        return formatter
    }

    private static let storageDay = formatter("yyyy-MM-dd")
    private static let storageTime = formatter("yyyy-MM-dd HH:mm:ss")
    private static let shownDay = formatter("dd-MM-yyyy")
    private static let shownTime = formatter("dd-MM-yyyy HH:mm")
    private static let storageMinute = formatter("yyyy-MM-dd HH:mm")
    private static let slashYear = formatter("d/M/yyyy")
    private static let slashShortYear = formatter("d/M/yy")

    static func parse(_ value: String) -> Date? {
        if value.contains("T") {
            let iso = ISO8601DateFormatter()
            iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = iso.date(from: value) { return date }
            iso.formatOptions = [.withInternetDateTime]
            if let date = iso.date(from: value) { return date }
        }
        if value.contains("/") {
            let year = value.split(separator: "/").last
            return (year?.count == 2 ? slashShortYear : slashYear).date(from: value)
        }
        let yearFirst = value.prefix(4).allSatisfy(\.isNumber)
        if yearFirst {
            if value.count == 19 { return storageTime.date(from: value) }
            if value.count == 16 { return storageMinute.date(from: value) }
            return storageDay.date(from: value)
        }
        return (value.count == 16 ? shownTime : shownDay).date(from: value)
    }

    static func display(_ value: String, time: Bool = false) -> String {
        guard let date = parse(value) else { return value }
        return display(date, time: time)
    }

    static func display(_ date: Date, time: Bool = false) -> String {
        (time ? shownTime : shownDay).string(from: date)
    }

    static func storage(_ date: Date, time: Bool = false) -> String {
        (time ? storageTime : storageDay).string(from: date)
    }

    static func sortKey(_ value: String) -> Date { parse(value) ?? .distantPast }
}

extension String {
    var filled: Bool { !trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
}


struct SearchPanel: View {
    @Binding var text: String
    @Environment(\.dismiss) private var dismiss
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            HStack(spacing: 12) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Buscar", text: $text)
                    .focused($focused)
                    .submitLabel(.search)
                    .onSubmit { dismiss() }
                if text.filled {
                    Button("Borrar búsqueda", systemImage: "xmark.circle.fill") { text = "" }
                        .labelStyle(.iconOnly).foregroundStyle(.secondary)
                }
            }
            .padding(14)
            .glassEffect(.regular, in: .capsule)
            .padding()
            .navigationTitle("Buscar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } }
            }
        }
        .tint(wine)
        .task {
            try? await Task.sleep(for: .milliseconds(250))
            guard !Task.isCancelled else { return }
            focused = true
        }
    }
}
