import Charts
import SwiftUI

struct EconomiaView: View {
    @Binding var book: Book
    @Binding var term: String
    @AppStorage("economiaPage") private var internalPage = false
    @State private var movement: WealthMovement?
    @State private var rate: CurrencyEntry?
    @State private var rename = false
    @State private var name = ""

    private var rates: [CurrencyEntry] { book.currencyEntries.sorted { BookDate.sortKey($0.date) < BookDate.sortKey($1.date) } }

    private var balanceConfirmed: Bool { book.activeBalanceCheckID != nil }

    private var timeline: [EconomyEvent] {
        let movements = book.wealthMovements.map(EconomyEvent.movement)
        let checks = book.balanceChecks.reversed().map(EconomyEvent.check)
        return (movements + checks)
            .enumerated()
            .filter { !term.filled || $0.element.searchText.localizedCaseInsensitiveContains(term) }
            .sorted {
                if $0.element.date == $1.element.date { return $0.offset < $1.offset }
                return $0.element.date > $1.element.date
            }
            .map(\.element)
    }

    var body: some View {
        BookPage {
            Picker("Economía", selection: $internalPage) {
                Label("Externo", systemImage: "wallet.bifold").tag(false)
                Label("Interno", systemImage: "coins").tag(true)
            }.pickerStyle(.segmented)

            if internalPage { internalContent }
            else { externalContent }
        }
        .sheet(item: $movement) { item in movementEditor(item) }
        .sheet(item: $rate) { item in rateEditor(item) }
        .alert("Nombre de la moneda", isPresented: $rename) {
            TextField("Nombre", text: $name)
            Button("Cancelar", role: .cancel) {}
            Button("Guardar") { if name.filled { book.currencyName = name } }
        }
    }

    private var externalContent: some View {
        PaperCard {
            HStack(spacing: 10) {
                Image(systemName: "wallet.bifold")
                    .padding(10).foregroundStyle(wine)
                    .background(wine.opacity(0.12), in: .rect(cornerRadius: 12))
                    .accessibilityHidden(true)
                VStack(alignment: .leading) {
                    Text("DINERO").font(.system(.title2, design: .serif, weight: .heavy))
                    Text("Monto en soles peruanos").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                Text("SOLES S/.").font(.caption.monospaced().bold())
                    .padding(7).foregroundStyle(wine)
                    .background(wine.opacity(0.12), in: .capsule)
            }
            VStack(spacing: 4) {
                HStack {
                    Color.clear.frame(width: 36, height: 36).accessibilityHidden(true)
                    Text("BALANCE TOTAL")
                        .font(.caption.monospaced().bold()).tracking(2)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                    Button {
                        guard !balanceConfirmed else { return }
                        let check = BalanceCheck(amount: book.wealthTotal, date: .now)
                        book.balanceChecks.append(check)
                        book.activeBalanceCheckID = check.id
                    } label: {
                        Image(systemName: "checkmark")
                            .font(.subheadline.bold())
                            .frame(width: 36, height: 36)
                            .foregroundStyle(balanceConfirmed ? Color.green : Color.primary)
                            .glassEffect(.regular.tint(balanceConfirmed ? Color.green.opacity(0.45) : nil).interactive(), in: .circle)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(balanceConfirmed ? "Saldo confirmado" : "Confirmar coincidencia con el banco")
                }
                .padding(.horizontal, 10)
                Text(soles(book.wealthTotal)).font(.system(.largeTitle, design: .monospaced, weight: .black))
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 18)
            .background(ruby.opacity(0.07), in: .rect(cornerRadius: 16))
            GlassEffectContainer(spacing: 12) {
                HStack(spacing: 12) {
                    moneyAction("Restar fondos", icon: "minus", type: "restar", color: wine)
                    moneyAction("Sumar fondos", icon: "plus", type: "sumar", color: .green)
                }
            }
            Divider().padding(.vertical, 4)
            Text("Movimientos recientes").font(.headline)
            if timeline.isEmpty {
                Text(term.filled ? "Sin resultados" : "Sin movimientos").foregroundStyle(.secondary)
            }
            ForEach(timeline) { event in
                switch event {
                case .movement(let item): movementRow(item)
                case .check(let check): balanceCheckRow(check)
                }
            }
        }
    }

    private func movementRow(_ item: WealthMovement) -> some View {
        Button { movement = item } label: {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.concept).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    Text(BookDate.display(item.date, time: true)).font(.caption.monospaced()).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    Text((item.type == "restar" ? "− " : "+ ") + soles(item.amount))
                        .font(.subheadline.monospaced().bold())
                        .foregroundStyle(item.type == "restar" ? wine : Color.green)
                    Text("Saldo: " + soles(item.balanceAfter)).font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(10)
            .background(ruby.opacity(0.06), in: .rect(cornerRadius: 12))
        }.buttonStyle(.plain)
    }

    private func balanceCheckRow(_ check: BalanceCheck) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("¡El monto coincide con el bancario!").font(.caption.bold())
            ViewThatFits(in: .horizontal) {
                HStack {
                    Text("Balance: " + soles(check.amount))
                    Spacer(minLength: 12)
                    Text(BookDate.display(check.date, time: true))
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Balance: " + soles(check.amount))
                    Text(BookDate.display(check.date, time: true))
                }
            }
            .font(.caption2.monospaced())
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 10).padding(.vertical, 7)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.black.opacity(0.70), in: .rect(cornerRadius: 9))
    }

    private var internalContent: some View {
        PaperCard {
            HStack {
                SectionHeading(title: book.currencyName, symbol: "coloncurrencysign.circle")
                Spacer()
                Button("Renombrar", systemImage: "pencil") { name = book.currencyName; rename = true }
                    .labelStyle(.iconOnly).buttonStyle(.glass)
                GlassAdd(label: "Nueva cotización") { rate = CurrencyEntry(date: today()) }
            }
            if let last = rates.last {
                Text("1 peso = S/ " + last.solesRate.formatted(.number.locale(Locale(identifier: "en_US")).precision(.fractionLength(0...6))))
                    .font(.headline.monospaced()).foregroundStyle(wine)
                Chart(rates) { item in
                    LineMark(x: .value("Fecha", item.date), y: .value("Soles", item.solesRate))
                        .foregroundStyle(wine)
                    PointMark(x: .value("Fecha", item.date), y: .value("Soles", item.solesRate))
                        .foregroundStyle(wine)
                }
                .chartYScale(domain: 0...max(1, (rates.map(\.solesRate).max() ?? 1)))
                .chartYAxis { AxisMarks(position: .leading, values: [0.0, 0.25, 0.5, 0.75, 1.0]) }
                .chartXAxis(.hidden)
                .frame(height: 180)
                HStack {
                    Text(BookDate.display(rates.first?.date ?? ""))
                    Spacer()
                    Text(BookDate.display(last.date))
                }.font(.caption.monospaced()).foregroundStyle(.secondary)
            }
            NavigationLink("Ver cotizaciones") {
                BookPage {
                    ForEach(rates.reversed().filter { !term.filled || [BookDate.display($0.date), $0.date, $0.notes ?? "", String($0.solesRate)].contains { $0.localizedCaseInsensitiveContains(term) } }) { item in
                        Button { rate = item } label: {
                            PaperCard {
                                Text(BookDate.display(item.date)).font(.headline.monospaced())
                                Text("S/ \(item.solesRate.formatted(.number.precision(.fractionLength(0...6))))").foregroundStyle(wine)
                                if let notes = item.notes { Text(notes).foregroundStyle(.secondary) }
                            }
                        }.buttonStyle(.plain)
                    }
                }
                .navigationTitle("Cotizaciones")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { GlassAdd { rate = CurrencyEntry(date: today()) } } }
            }.buttonStyle(.glass)
        }
    }

    private func moneyAction(_ title: String, icon: String, type: String, color: Color) -> some View {
        Button {
            movement = WealthMovement(type: type, date: nowStamp())
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.bold())
                .frame(maxWidth: .infinity, minHeight: 44)
                .glassEffect(.regular.tint(color.opacity(0.24)).interactive(), in: .capsule)
        }.buttonStyle(.plain)
    }

    private func signed(_ entry: WealthMovement) -> Double { entry.type == "restar" ? -entry.amount : entry.amount }

    private var openingBalance: Double {
        book.wealthTotal - book.wealthMovements.reduce(0) { $0 + signed($1) }
    }

    private func updateMovements(_ movements: [WealthMovement], opening: Double) {
        var running = opening
        let ordered = movements.enumerated().sorted {
            let first = BookDate.sortKey($0.element.date)
            let second = BookDate.sortKey($1.element.date)
            return first == second ? $0.offset > $1.offset : first < second
        }
        let recalculated = ordered.map { pair in
            var row = pair.element
            running = ((running + signed(row)) * 100).rounded() / 100
            row.balanceAfter = running
            return row
        }
        book.wealthMovements = Array(recalculated.reversed())
        book.wealthTotal = running
        book.activeBalanceCheckID = nil
    }

    private func movementEditor(_ item: WealthMovement) -> some View {
        let existing = book.wealthMovements.contains { $0.id == item.id }
        return EntryEditor(item, title: existing ? "Editar movimiento" : "Movimiento de dinero", valid: { draft in
            draft.amount.isFinite && draft.amount > 0 && draft.concept.filled && draft.date.filled &&
            book.wealthTotal - (existing ? signed(item) : 0) + signed(draft) >= -0.0001
        }, save: { draft in
            var rows = book.wealthMovements
            rows.put(draft)
            updateMovements(rows, opening: openingBalance)
        }, delete: existing ? {
            updateMovements(book.wealthMovements.filter { $0.id != item.id }, opening: openingBalance)
        } : nil, toolbarTint: { $0.type == "sumar" ? .green : wine }) { value in
            Picker("Operación", selection: value.type) {
                Label("Restar", systemImage: "minus").tag("restar")
                Label("Sumar", systemImage: "plus").tag("sumar")
            }.pickerStyle(.segmented)
            let color = value.wrappedValue.type == "restar" ? wine : Color.green
            DecimalField(title: "Cantidad en soles", value: value.amount, autofocus: !existing)
                .monospacedDigit()
                .foregroundStyle(color)
                .padding(9)
                .overlay { RoundedRectangle(cornerRadius: 8).strokeBorder(color.opacity(0.45)).allowsHitTesting(false) }
            TextField("Concepto / Motivo", text: value.concept)
            DayField(title: "Fecha y hora", value: value.date, includesTime: true)
            LabeledContent("Saldo resultante", value: soles(book.wealthTotal - (existing ? signed(item) : 0) + signed(value.wrappedValue)))
        }
    }

    private func rateEditor(_ item: CurrencyEntry) -> some View {
        EntryEditor(item, title: "Cotización", valid: { $0.solesRate.isFinite && $0.solesRate > 0 }, save: { draft in
            var row = draft
            if row.date != item.date { row.displayDate = nil }
            book.currencyEntries.put(row)
        }, delete: book.currencyEntries.contains { $0.id == item.id } ? {
            book.currencyEntries.removeAll { $0.id == item.id }
        } : nil) { value in
            DayField(title: "Fecha", value: value.date)
            DecimalField(title: "Valor en soles", value: value.solesRate)
            TextField("Notas", text: optionalText(value.notes))
        }
    }
}

struct DecimalField: View {
    var title: String
    @Binding var value: Double
    @State private var input: String
    @FocusState private var focused: Bool
    var autofocus: Bool

    init(title: String, value: Binding<Double>, autofocus: Bool = false) {
        self.title = title
        self.autofocus = autofocus
        self._value = value
        self._input = State(initialValue: value.wrappedValue == 0 ? "" :
            value.wrappedValue.formatted(.number.grouping(.never).precision(.fractionLength(0...8))))
    }

    var body: some View {
        TextField(title, text: $input)
            .keyboardType(.decimalPad)
            .focused($focused)
            .task {
                guard autofocus else { return }
                try? await Task.sleep(for: .milliseconds(350))
                guard !Task.isCancelled else { return }
                focused = true
            }
            .onChange(of: input) { _, text in
                let amount = Double(text.replacingOccurrences(of: ",", with: "."))
                value = amount?.isFinite == true ? (amount ?? 0) : 0
            }
    }
}


private enum EconomyEvent: Identifiable {
    case movement(WealthMovement)
    case check(BalanceCheck)

    var id: String {
        switch self {
        case .movement(let item): return "movement-" + item.id
        case .check(let item): return "check-" + item.id
        }
    }

    var date: Date {
        switch self {
        case .movement(let item): return BookDate.sortKey(item.date)
        case .check(let item): return item.date
        }
    }

    var searchText: String {
        switch self {
        case .movement(let item):
            return [item.concept, BookDate.display(item.date, time: true), item.date, soles(item.amount)].joined(separator: " ")
        case .check(let item):
            return ["El monto coincide con el bancario", BookDate.display(item.date, time: true), soles(item.amount)].joined(separator: " ")
        }
    }
}
