import Charts
import SwiftUI

struct EconomiaView: View {
    @Binding var book: Book
    @AppStorage("economiaPage") private var internalPage = false
    @State private var movement: WealthMovement?
    @State private var rate: CurrencyEntry?
    @State private var rename = false
    @State private var name = ""

    private var rates: [CurrencyEntry] { book.currencyEntries.sorted { $0.date < $1.date } }

    var body: some View {
        BookPage {
            Picker("Economía", selection: $internalPage) {
                Label("Externo", systemImage: "wallet.bifold").tag(false)
                Label("Interno", systemImage: "coins").tag(true)
            }.pickerStyle(.segmented)

            if internalPage { internalContent }
            else { externalContent }
        }
        .sheet(item: $movement) { item in movementEditor(item) }
        .sheet(item: $rate) { item in rateEditor(item) }
        .alert("Nombre de la moneda", isPresented: $rename) {
            TextField("Nombre", text: $name)
            Button("Cancelar", role: .cancel) {}
            Button("Guardar") { if name.filled { book.currencyName = name } }
        }
    }

    private var externalContent: some View {
        PaperCard {
            HStack(spacing: 10) {
                Image(systemName: "wallet.bifold")
                    .padding(10).foregroundStyle(wine)
                    .background(wine.opacity(0.12), in: .rect(cornerRadius: 12))
                    .accessibilityHidden(true)
                VStack(alignment: .leading) {
                    Text("DINERO").font(.system(.title2, design: .serif, weight: .heavy))
                    Text("Monto en soles peruanos").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                Text("SOLES S/.").font(.caption.monospaced().bold())
                    .padding(7).foregroundStyle(wine)
                    .background(wine.opacity(0.12), in: .capsule)
            }
            VStack(spacing: 4) {
                Text("BALANCE TOTAL").font(.caption.monospaced().bold()).tracking(2).foregroundStyle(.secondary)
                Text(soles(book.wealthTotal)).font(.system(.largeTitle, design: .monospaced, weight: .black))
            }
            .frame(maxWidth: .infinity).padding(.vertical, 18)
            .background(ruby.opacity(0.07), in: .rect(cornerRadius: 16))
            GlassEffectContainer(spacing: 12) {
                HStack(spacing: 12) {
                    moneyAction("Restar fondos", icon: "minus", type: "restar", color: wine)
                    moneyAction("Sumar fondos", icon: "plus", type: "sumar", color: .green)
                }
            }
            Divider().padding(.vertical, 4)
            Text("Movimientos recientes").font(.headline)
            if book.wealthMovements.isEmpty {
                Text("Sin movimientos").foregroundStyle(.secondary)
            }
            ForEach(book.wealthMovements.sorted { $0.date > $1.date }) { item in
                Button { movement = item } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.concept).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                            Text(item.date).font(.caption.monospaced()).foregroundStyle(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            Text((item.type == "restar" ? "− " : "+ ") + soles(item.amount))
                                .font(.subheadline.monospaced().bold())
                                .foregroundStyle(item.type == "restar" ? wine : Color.green)
                            Text("Saldo: " + soles(item.balanceAfter)).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(10)
                    .background(ruby.opacity(0.06), in: .rect(cornerRadius: 12))
                }.buttonStyle(.plain)
            }
        }
    }

    private var internalContent: some View {
        PaperCard {
            HStack {
                SectionHeading(title: book.currencyName, symbol: "coloncurrencysign.circle")
                Spacer()
                Button("Renombrar", systemImage: "pencil") { name = book.currencyName; rename = true }
                    .labelStyle(.iconOnly).buttonStyle(.glass)
                GlassAdd(label: "Nueva cotización") { rate = CurrencyEntry(date: today()) }
            }
            if let last = rates.last {
                Text("1 peso = S/ " + last.solesRate.formatted(.number.locale(Locale(identifier: "en_US")).precision(.fractionLength(0...6))))
                    .font(.headline.monospaced()).foregroundStyle(wine)
                Chart(rates) { item in
                    LineMark(x: .value("Fecha", item.date), y: .value("Soles", item.solesRate))
                        .foregroundStyle(wine)
                    PointMark(x: .value("Fecha", item.date), y: .value("Soles", item.solesRate))
                        .foregroundStyle(wine)
                }
                .chartYScale(domain: 0...max(1, (rates.map(\.solesRate).max() ?? 1)))
                .chartYAxis { AxisMarks(position: .leading, values: [0.0, 0.25, 0.5, 0.75, 1.0]) }
                .chartXAxis(.hidden)
                .frame(height: 180)
                HStack {
                    Text(rates.first?.date ?? "")
                    Spacer()
                    Text(last.date)
                }.font(.caption.monospaced()).foregroundStyle(.secondary)
            }
            NavigationLink("Ver cotizaciones") {
                BookPage {
                    ForEach(Array(rates.reversed())) { item in
                        Button { rate = item } label: {
                            PaperCard {
                                Text(item.displayDate ?? item.date).font(.headline.monospaced())
                                Text("S/ \(item.solesRate.formatted(.number.precision(.fractionLength(0...6))))").foregroundStyle(wine)
                                if let notes = item.notes { Text(notes).foregroundStyle(.secondary) }
                            }
                        }.buttonStyle(.plain)
                    }
                }
                .navigationTitle("Cotizaciones")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { GlassAdd { rate = CurrencyEntry(date: today()) } } }
            }.buttonStyle(.glass)
        }
    }

    private func moneyAction(_ title: String, icon: String, type: String, color: Color) -> some View {
        Button {
            movement = WealthMovement(type: type, date: nowStamp())
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.bold())
                .frame(maxWidth: .infinity, minHeight: 44)
                .glassEffect(.regular.tint(color.opacity(0.24)).interactive(), in: .capsule)
        }.buttonStyle(.plain)
    }

    private func signed(_ entry: WealthMovement) -> Double { entry.type == "restar" ? -entry.amount : entry.amount }

    private var openingBalance: Double {
        book.wealthTotal - book.wealthMovements.reduce(0) { $0 + signed($1) }
    }

    private func updateMovements(_ movements: [WealthMovement], opening: Double) {
        var running = opening
        let ordered = movements.enumerated().sorted {
            $0.element.date == $1.element.date ? $0.offset > $1.offset : $0.element.date < $1.element.date
        }
        let recalculated = ordered.map { pair in
            var row = pair.element
            running = ((running + signed(row)) * 100).rounded() / 100
            row.balanceAfter = running
            return row
        }
        book.wealthMovements = Array(recalculated.reversed())
        book.wealthTotal = running
    }

    private func movementEditor(_ item: WealthMovement) -> some View {
        let existing = book.wealthMovements.contains { $0.id == item.id }
        return EntryEditor(item, title: existing ? "Editar movimiento" : "Movimiento de dinero", valid: { draft in
            draft.amount.isFinite && draft.amount > 0 && draft.concept.filled && draft.date.filled &&
            book.wealthTotal - (existing ? signed(item) : 0) + signed(draft) >= -0.0001
        }, save: { draft in
            var rows = book.wealthMovements
            rows.put(draft)
            updateMovements(rows, opening: openingBalance)
        }, delete: existing ? {
            updateMovements(book.wealthMovements.filter { $0.id != item.id }, opening: openingBalance)
        } : nil) { value in
            Picker("Operación", selection: value.type) {
                Label("Restar", systemImage: "minus").tag("restar")
                Label("Sumar", systemImage: "plus").tag("sumar")
            }.pickerStyle(.segmented)
            let color = value.wrappedValue.type == "restar" ? wine : Color.green
            DecimalField(title: "Cantidad en soles", value: value.amount)
                .monospacedDigit()
                .foregroundStyle(color)
                .padding(9)
                .overlay { RoundedRectangle(cornerRadius: 8).strokeBorder(color.opacity(0.45)).allowsHitTesting(false) }
            TextField("Concepto / Motivo", text: value.concept)
            TextField("Fecha y hora", text: value.date)
                .font(.system(.body, design: .monospaced)).autocorrectionDisabled()
            LabeledContent("Saldo resultante", value: soles(book.wealthTotal - (existing ? signed(item) : 0) + signed(value.wrappedValue)))
        }
    }

    private func rateEditor(_ item: CurrencyEntry) -> some View {
        EntryEditor(item, title: "Cotización", valid: { $0.solesRate.isFinite && $0.solesRate > 0 }, save: { draft in
            var row = draft
            if row.date != item.date { row.displayDate = nil }
            book.currencyEntries.put(row)
        }, delete: book.currencyEntries.contains { $0.id == item.id } ? {
            book.currencyEntries.removeAll { $0.id == item.id }
        } : nil) { value in
            DayField(title: "Fecha", value: value.date)
            DecimalField(title: "Valor en soles", value: value.solesRate)
            TextField("Notas", text: optionalText(value.notes))
        }
    }
}

struct DecimalField: View {
    var title: String
    @Binding var value: Double
    @State private var input: String

    init(title: String, value: Binding<Double>) {
        self.title = title
        self._value = value
        self._input = State(initialValue: value.wrappedValue == 0 ? "" :
            value.wrappedValue.formatted(.number.grouping(.never).precision(.fractionLength(0...8))))
    }

    var body: some View {
        TextField(title, text: $input)
            .keyboardType(.decimalPad)
            .onChange(of: input) { _, text in
                let amount = Double(text.replacingOccurrences(of: ",", with: "."))
                value = amount?.isFinite == true ? (amount ?? 0) : 0
            }
    }
}
