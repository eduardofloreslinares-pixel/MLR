import Foundation

struct Norma: Codable, Identifiable {
    var id: String = UUID().uuidString
    var randomCode: Int = 0
    var type: String = ""
    var customTypeLabel: String? = nil
    var titleSuffix: String = ""
    var fullTitle: String = ""
    var displayId: String = ""
    var issuedBy: String = ""
    var content: String = ""
    var date: String = ""
    var status: String = ""
    var derogatedAt: String? = nil
    var derogatedByName: String? = nil
    var derogatedByNormaId: String? = nil
    var derogationReason: String? = nil
    var derogatedBy: String? = nil
    var correspondencias: [String] = []
    var marcoComunCorrespondencias: [String] = []
}

struct MarcoComunRegla: Codable, Identifiable {
    var id: String = UUID().uuidString
    var number: Int = 0
    var text: String = ""
}

struct Veto: Codable, Identifiable {
    var id: String = UUID().uuidString
    var randomCode: Int = 0
    var targetType: String = ""
    var name: String = ""
    var photoUrl: String? = nil
    var reasons: String = ""
    var date: String = ""
    var severity: String = ""
    var status: String = ""
    var liftedAt: String? = nil
    var liftReason: String? = nil
}

struct CurrencyEntry: Codable, Identifiable {
    var id: String = UUID().uuidString
    var date: String = ""
    var displayDate: String? = nil
    var solesRate: Double = 0
    var notes: String? = nil
}

struct WealthMovement: Codable, Identifiable {
    var id: String = UUID().uuidString
    var type: String = ""
    var amount: Double = 0
    var concept: String = ""
    var date: String = ""
    var balanceAfter: Double = 0
}

struct Logro: Codable, Identifiable {
    var id: String = UUID().uuidString
    var title: String = ""
    var description: String = ""
    var amountSoles: Double? = nil
    var date: String = ""
    var category: String = ""
}

struct Pendiente: Codable, Identifiable {
    var id: String = UUID().uuidString
    var processingOrder: Int? = nil
    var orderNumber: Int = 0
    var content: String = ""
    var dueDate: String = ""
    var importance: String = ""
    var status: String = ""
    var postponedUntil: String? = nil
    var postponeReason: String? = nil
    var completedAt: String? = nil
    var notes: String? = nil
    var createdAt: String = ""
}

struct NewspaperEntry: Codable, Identifiable {
    var id: String = UUID().uuidString
    var text: String = ""
}

struct Book: Codable {
    var newspaper: [NewspaperEntry] = []
    var normas: [Norma] = []
    var marcoComun: [MarcoComunRegla] = []
    var vetos: [Veto] = []
    var currencyEntries: [CurrencyEntry] = []
    var currencyName = "Peso Eduardino"
    var wealthTotal: Double = 0
    var wealthMovements: [WealthMovement] = []
    var logros: [Logro] = []
    var pendientes: [Pendiente] = []
    var appName = "Mi Libro Rojo"
    var version = "2.0.0"
    var exportedAt: String?

    init(currencyEntries: [CurrencyEntry] = []) {
        self.currencyEntries = currencyEntries
    }

    init(from decoder: Decoder) throws {
        let data = try decoder.container(keyedBy: CodingKeys.self)
        normas = try data.decode([Norma].self, forKey: .normas)
        marcoComun = try data.decode([MarcoComunRegla].self, forKey: .marcoComun)
        vetos = try data.decode([Veto].self, forKey: .vetos)
        currencyEntries = try data.decode([CurrencyEntry].self, forKey: .currencyEntries)
        currencyName = try data.decode(String.self, forKey: .currencyName)
        wealthTotal = try data.decode(Double.self, forKey: .wealthTotal)
        wealthMovements = try data.decode([WealthMovement].self, forKey: .wealthMovements)
        logros = try data.decode([Logro].self, forKey: .logros)
        pendientes = try data.decode([Pendiente].self, forKey: .pendientes)
        newspaper = try data.decodeIfPresent([NewspaperEntry].self, forKey: .newspaper) ?? []
        appName = try data.decodeIfPresent(String.self, forKey: .appName) ?? "Mi Libro Rojo"
        version = try data.decodeIfPresent(String.self, forKey: .version) ?? "2.0.0"
        exportedAt = try data.decodeIfPresent(String.self, forKey: .exportedAt)
    }

    static let historicalRates: [CurrencyEntry] = [
        CurrencyEntry(id: "peso-history-19-0", date: "2018-12-01", solesRate: 0.8456),
        CurrencyEntry(id: "peso-history-19-1", date: "2018-12-29", solesRate: 0.7655),
        CurrencyEntry(id: "peso-history-19-2", date: "2019-03-12", solesRate: 0.4523),
        CurrencyEntry(id: "peso-history-19-3", date: "2019-03-20", solesRate: 0.2455),
        CurrencyEntry(id: "peso-history-19-4", date: "2019-05-05", solesRate: 0.1585),
        CurrencyEntry(id: "peso-history-19-5", date: "2019-06-15", solesRate: 0.2456),
        CurrencyEntry(id: "peso-history-19-6", date: "2019-09-14", solesRate: 0.1),
        CurrencyEntry(id: "peso-history-19-7", date: "2019-11-20", solesRate: 0.051),
        CurrencyEntry(id: "peso-history-19-8", date: "2020-03-03", solesRate: 0.013),
        CurrencyEntry(id: "peso-history-19-9", date: "2020-12-12", solesRate: 0.069),
        CurrencyEntry(id: "peso-history-19-10", date: "2021-02-02", solesRate: 0.025),
        CurrencyEntry(id: "peso-history-19-11", date: "2021-08-20", solesRate: 0.025),
        CurrencyEntry(id: "peso-history-19-12", date: "2021-12-02", solesRate: 0.012),
        CurrencyEntry(id: "peso-history-19-13", date: "2022-03-03", solesRate: 0.0569),
        CurrencyEntry(id: "peso-history-19-14", date: "2022-12-12", solesRate: 0.12),
        CurrencyEntry(id: "peso-history-19-15", date: "2023-06-05", solesRate: 0.3441),
        CurrencyEntry(id: "peso-history-19-16", date: "2023-12-12", solesRate: 0.189),
        CurrencyEntry(id: "peso-history-19-17", date: "2024-08-15", solesRate: 0.25),
        CurrencyEntry(id: "peso-history-19-18", date: "2024-12-12", solesRate: 0.184),
        CurrencyEntry(id: "peso-history-19-19", date: "2025-03-01", solesRate: 0.234),
        CurrencyEntry(id: "peso-history-19-20", date: "2025-06-06", solesRate: 0.153),
        CurrencyEntry(id: "peso-history-19-21", date: "2025-08-12", solesRate: 0.1521),
        CurrencyEntry(id: "peso-history-19-22", date: "2025-12-21", solesRate: 0.2301),
        CurrencyEntry(id: "peso-history-19-23", date: "2025-12-25", solesRate: 0.1851),
        CurrencyEntry(id: "peso-history-19-24", date: "2026-01-05", solesRate: 0.0995),
    ]
}
