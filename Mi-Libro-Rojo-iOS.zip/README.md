# Mi Libro Rojo para iOS

Proyecto SwiftUI nativo basado en Mi Libro Rojo 1.14 de Android. Requiere iOS 26 o posterior. Conserva la paleta granate y rosa, los tonos de papel, el modo oscuro automático y la cabecera horizontal de Dinero. La navegación, la barra de pestañas y los controles principales usan Liquid Glass de SwiftUI.

## Compilar la IPA en GitHub

El ZIP contiene el proyecto Xcode y el workflow `.github/workflows/build-ipa.yml`. Puedes usar cualquiera de estas dos formas:

1. **Subir el ZIP:** sube `Mi-Libro-Rojo-iOS.zip` a la raíz del repositorio. En GitHub elige **Add file → Create new file**, escribe `.github/workflows/build-ipa.yml` como ruta, pega el contenido de `workflow-para-github.txt` incluido en el ZIP y guarda el archivo. GitHub solo detecta workflows que están fuera del ZIP y guardados en esa ruta del repositorio.
2. **Subir los archivos extraídos:** descomprime el ZIP y sube los archivos a la raíz del repo, incluyendo `.github/workflows/build-ipa.yml`. Si Archivos en el iPhone oculta la carpeta `.github`, puedes crear el workflow desde la web de GitHub como en el paso anterior.

Luego ve a **Actions → Compilar IPA de Mi Libro Rojo → Run workflow**. Al terminar, descarga el artefacto **Mi-Libro-Rojo-iOS** y extrae **Mi-Libro-Rojo.ipa**. El artefacto de GitHub es un ZIP que contiene la IPA.

La IPA se genera **sin firma**. Usa el mismo proceso de firma e instalación con iLoader y SideStore que usaste para Degusta. El workflow no requiere la contraseña de Apple, certificados ni secretos.

En Mac también puedes abrir `LibroRojo.xcodeproj` en Xcode 26 o superior. Para instalar desde Xcode, elige tu equipo de firma en **Signing & Capabilities**.

## Pasar tus datos de Android

En Mi Libro Rojo de Android exporta la copia JSON. Pásala a Archivos en el iPhone y, en la versión iOS, toca **••• → Importar copia JSON**. La app te pedirá confirmar antes de reemplazar los datos existentes. Puedes exportar otra copia desde el mismo menú.

Los datos viven en este dispositivo. La primera apertura incluye las cotizaciones históricas del Peso Eduardino. Normas, Marco Común, Periódico, Vetos, Dinero, Avances y Pendientes se llenan al importar o al crear entradas.
